"""empty message

Revision ID: fea72f024367
Revises: 4d48d97eb80d, bursa20251216
Create Date: 2025-12-16 14:19:45.908426

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'fea72f024367'
down_revision = ('4d48d97eb80d', 'bursa20251216')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
