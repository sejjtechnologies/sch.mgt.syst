School Management System Backup
Created: 2025-12-20 13:55:43
Type: Manual Backup

This backup contains:
- Complete database data export (JSON format)
- Database file (if SQLite)
- Migration files
- Uploaded files and documents

Data includes:
- User accounts and profiles
- Pupil records and information
- School classes and streams
- Teacher assignments
- Attendance records
- Bursar settings and fee structures
- Payment records and methods
- System settings and configuration

To restore this backup, use the restore functionality in the admin panel.
