School Management System Backup
Created: 2025-12-19 20:37:37
Database: External Database

This backup contains:
- Database schema and data (if using SQLite)
- Migration files
- Uploaded files and documents

To restore:
1. Extract this zip file
2. If using SQLite, replace the database.db file
3. Run database migrations if needed
4. Restore any uploaded files to the instance directory
