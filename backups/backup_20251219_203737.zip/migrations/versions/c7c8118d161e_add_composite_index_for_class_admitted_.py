"""Add composite index for class_admitted and stream on pupils table

Revision ID: c7c8118d161e
Revises: 5c93e2aa0cc8
Create Date: 2025-12-15 16:56:44.521671

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c7c8118d161e'
down_revision = '5c93e2aa0cc8'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
